# hohovery
Aplicación web para delivery de artículos navideños, desarrollado en base a JS vanilla, PHP y mariadb.
